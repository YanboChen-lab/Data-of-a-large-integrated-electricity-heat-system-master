# Data-of-a-large-integrated-electricity-heat-system
The data of 200-node heat system and the data of a modified IEEE 1888-bus electrtcity system are given.
